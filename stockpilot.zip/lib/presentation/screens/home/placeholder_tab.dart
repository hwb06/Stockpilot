import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../controllers/auth_controller.dart';
import '../../../core/constants/app_strings.dart';
import '../../widgets/empty_state.dart';

class PlaceholderTab extends StatelessWidget {
  const PlaceholderTab({
    super.key,
    required this.title,
    required this.icon,
    this.showLogout = false,
  });

  final String title;
  final IconData icon;
  final bool showLogout;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        actions: [
          if (showLogout)
            IconButton(
              tooltip: AppStrings.logoutTooltip,
              icon: const Icon(Icons.logout),
              onPressed: Get.find<AuthController>().confirmSignOut,
            ),
        ],
      ),
      body: Center(
        child: EmptyState(
          icon: icon,
          title: title,
          message: AppStrings.comingSoon,
        ),
      ),
    );
  }
}
