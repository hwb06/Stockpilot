import 'package:flutter/material.dart';
import '../../core/constants/app_dimensions.dart';

class ChipOption {
  const ChipOption({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;
}

class ChoiceChipRow extends StatelessWidget {
  const ChoiceChipRow({super.key, required this.options});

  final List<ChipOption> options;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(
        horizontal: AppDimensions.pagePadding,
      ),
      child: Row(
        children: [
          for (final option in options)
            Padding(
              padding: const EdgeInsets.only(right: AppDimensions.spaceS),
              child: ChoiceChip(
                label: Text(option.label),
                selected: option.selected,
                onSelected: (_) => option.onTap(),
              ),
            ),
        ],
      ),
    );
  }
}
