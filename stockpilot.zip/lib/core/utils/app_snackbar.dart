import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../constants/app_colors.dart';
import '../constants/app_dimensions.dart';

class AppSnackbar {
  AppSnackbar._();

  static void success(String message) => _show('Success', message, AppColors.success);
  static void error(String message) => _show('Error', message, AppColors.danger);

  static void _show(String title, String message, Color color) {
    Get.snackbar(
      title,
      message,
      snackPosition: SnackPosition.BOTTOM,
      backgroundColor: color,
      colorText: AppColors.onPrimary,
      margin: const EdgeInsets.all(AppDimensions.spaceL),
      borderRadius: 12,
      duration: const Duration(seconds: 3),
    );
  }
}